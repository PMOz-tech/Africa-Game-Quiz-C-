﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace AfricanGame
{
    public class QuesAnsw {
        public int intQuestNumber = 0;
        public int intRow = 0;
        public int intCorrect = 0;
        public static string strName;
        public static bool quizResume = false;



        public static string[,] strQuestions = {{"What is the capital of Algeria?", "Abuja", "Port-Novo", "Algiers", "Yaounde", "1", String.Empty},
                                       {"What is the capital of Angola?", "Monrovia", "Luanda", "Banjul", "Accra", "2", String.Empty},
                                       {"What is the capital of Benin?", "Porto-Novo", "Cotonou", "Por-Neaveu", "Libreville", "1", String.Empty},
                                       {"What is the capital of Botswana?", "Addis Ababa", "N'Djamena", "Gaborone", "Luanda", "3", String.Empty},
                                       {"What is the capital of Burkina Faso?", "Lilongue", "Ouagadougou", "Malabo", "Brazzaville", "2", String.Empty},
                                       {"What is the capital of Burundi?", "Yamoussoukro", "Bujumbra", "Asmara", "Libreville", "2", String.Empty},
                                       {"What is the capital of Cameroon?", "Tripoli", "Bamako", "Yaounde", "Port Louis", "3", String.Empty},
                                       {"What is the capital of The republic of cabo Verde?", "Luanda", "Algiers", "Conakry", "Praia", "4", String.Empty},
                                       {"What is the capital of The Central African Republic?", "Bissau", "Noukachott", "Bangui", "Nairobi", "3", String.Empty},
                                       {"What is the capital of Chad?", "N'Djamena", "Cairo", "Yaounde", "Banjul", "1", String.Empty},
                                       {"What is the capital of Comoros?", "ibreville", "Tripoli", "Asmara", "Moroni", "4", String.Empty},
                                       {"What is the capital of Democratic Republic of Congo?", "Port Louis", "Kinshasa", "Maseru", "Bamako", "2", String.Empty},
                                       {"What is the capital of Republic of Congo?", "Brazzaville", "Tripoli", "Lilongwe", "Windhoek", "1", String.Empty},
                                       {"What is the capital of Cote d'Ivoire?", "Yaounde", "Bangui", "Yamoussoukro", "Antananarivo", "3", String.Empty},
                                       {"What is the capital of Djibouti?", "Maseru", "Tripoli", "Nouakchott", "Djibouti", "4", String.Empty},
                                       {"What is the capital of Egypt?", "Bamako", "Cairo", "Abuja", "Niamey", "2", String.Empty},
                                       {"What is the capital of Equatorial Guinea?", "Malabo", "Nairobi", "Antananarivo", "Port Louis", "1", String.Empty},
                                       {"What is the capital of Eritrea?", "Libreville", "Bissau", "Lilongwe", "Asmara", "4", String.Empty},
                                       {"What is the capital of Ethiopia?", "Djibouti", "Addis Ababa", "Windhoek", "Praia", "2", String.Empty},
                                       {"What is the capital of Gabon?", "Nouakchott", "Yamoussoukro", "Accra", "Libreville", "3", String.Empty},
                                       {"What is the capital of Gambia?", "Kigali", "Banjul", "Juba", "Rabat", "2", String.Empty},
                                       {"What is the capital of Ghana?", "Salaam", "Accra", "Mbabane", "Khartoum", "2", String.Empty},
                                       {"What is the capital of Guinea?", "Asmara", "Gambia", "Conakry", "Ethiopia", "3", String.Empty},
                                       {"What is the capital of Guinea-Bissau?", "Bissau", "Niamey", "Victoria", "Rwanda", "1", String.Empty},
                                       {"What is the capital of Kenya?", "Khartoum", "Mogadishu", "Seychelles", "Nairobi", "4", String.Empty},
                                       {"What is the capital of Lesotho?", "Dodoma", "Maseru", "Freetown", "Lilongwe", "2", String.Empty},
                                       {"What is the capital of Liberia?", "Monrovia", "Brazzaville", "Maseru", "Luanda", "1", String.Empty},
                                       {"What is the capital of Libya?", "Tripoli", "Mbabane", "Juba", "Salaam", "1", String.Empty},
                                       {"What is the capital of Madagascar?", "Antananarivo", "Freetown", "Yamoussoukro", "Ethiopia", "1", String.Empty},
                                       {"What is the capital of Malawi?", "Cairo", "Djibouti", "Lilongwe", "Mbabane", "3", String.Empty},
                                       {"What is the capital of Mali?", "Rwanda", "Bamako", "Khartoum", "Accra", "2", String.Empty},
                                       {"What is the capital of Mauritania?", "Mogadishu", "Bissau", "Nouakchott", "Dodoma", "3", String.Empty},
                                       {"What is the capital of Mauritius?", "Port Louis", "Lilongwe", "Niamey", "Salaam", "1", String.Empty},
                                       {"What is the capital of Morocco?", "Rabat", "Seychelles", "Banjul", "Asmara", "1", String.Empty},
                                       {"What is the capital of Mozambique?", "Principe", "Khartoum", "Juba", "Maputo", "4", String.Empty},
                                       {"What is the capital of Namibia?", "Dodoma", "Rabat", "Windhoek", "Mogadishu", "3", String.Empty},
                                       {"What is the capital of Niger?", "Lome", "Niamey", "Harare", "Tunis", "2", String.Empty},
                                       {"What is the capital of Nigeria", "Accra", "Abuja", "Cairo", "Asmara", "2", String.Empty},
                                       {"What is the capital of Rwanda?", "Mbabane", "Dodoma", "Nouakchott", "Kigali", "4", String.Empty},
                                       {"What is the capital of Republic Arab Saharawi Democratic?", "Banjul", "Luanda", "Niamey", "Aauin", "4", String.Empty},
                                       {"What is the capital of Sao Tome and Principe?", "Rabat", "Maputo", "Antananarivo", "Sao Tome", "4", String.Empty},                                              
                                       {"What is the capital of Senegal?", "Conakry", "Monrovia", "Dakar", "Windhoek", "3", String.Empty},
                                       {"What is the capital of Seychelles?", "Rabat", "Mbabane", "Victoria", "Yamoussoukro", "3", String.Empty},
                                       {"What is the capital of Sierra Leone?", "Maseru", "Freetown", "Harare", "Tunis", "2", String.Empty},
                                       {"What is the capital of Somalia?", "Mogadishu", "Tunis", "Abuja", "Lusaka", "1", String.Empty},
                                       {"What is the capital of South Africa?", "Pretoria", "Juba", "Banjul", "Rwanda", "1", String.Empty},
                                       {"What is the capital of South Sudan?", "Kigali", "Juba", "Maseru", "Conakry", "2", String.Empty},
                                       {"What is the capital of Sudan?", "Lilongwe", "Victoria", "Maseru", "Khartoum", "4", String.Empty},
                                       {"What is the capital of Swaziland?", "Lobamba", "Djibouti", "Tunis", "Asmara", "1", String.Empty},
                                       {"What is the capital of Tanzania?", "Dodoma", "Mogadishu", "Tripoli", "Nouakchott", "1", String.Empty},
                                       {"What is the capital of Togo?", "Rabat", "Lome", "Niamey", "Mali", "2", String.Empty},
                                       {"What is the capital of Tunisia?", "Lilongwe", "Tunis", "Mbabane", "Kigali", "2", String.Empty},
                                       {"What is the capital of Uganda?", "Dakar", "Kampala", "Niamey", "Tome", "2", String.Empty},
                                       {"What is the capital of Zambia?", "Khartoum", "Lusaka", "Kigali", "Freetown", "2", String.Empty},
                                       {"What is the capital of Zimbabwe?", "Niamey", "Harare", "Windhoek", "Maseru", "2", String.Empty}};



        public static int TestScore() {
            int Score = 0;
            for (int i = 0; i <= strQuestions.GetUpperBound(0); i+=5) {
                if (strQuestions[i, 5] == strQuestions[i, 6]) {
                    Score++;
                }              
            }
            return Score;
        }

        public void ResetAnswers() {
            for (int i = 0; i <= strQuestions.GetUpperBound(0); i++) {
                strQuestions[i, 6] = String.Empty;
            }
        }
    }
    public class Timer {
        public int timerTickCount = 0;
        private bool hasSelectionChanged = false;
        private DispatcherTimer timer;

        public Timer() {
            timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0, 0, 1); // will 'tick' once every second
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e) {
            DispatcherTimer timer = (DispatcherTimer)sender;
            if (++timerTickCount == 2) {
                if (hasSelectionChanged) timer.Stop();
            }
        }
    }
}
